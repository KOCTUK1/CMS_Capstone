from django.shortcuts import render

def index(request):
    return render(request, 'predictor/index.html')

def room_detail(request):
    return render(request, 'predictor/room_detail.html')

def about(request):
    return render(request, 'predictor/about.html')

def admin_data(request):
    return render(request, 'predictor/admin_data.html')