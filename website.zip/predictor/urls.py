from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('room/', views.room_detail, name='room_detail'),
    path('about/', views.about, name='about'),
    path('admin-data/', views.admin_data, name='admin_data'),
]